<?php 
$koneksi = mysqli_connect('localhost','root','','teman_bunda');
?>