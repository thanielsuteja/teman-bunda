

<?php $__env->startSection('content'); ?>
<div class="container rounded border border-dark bg-dark p-5" style="margin-left:20%; margin-top:5%; height:50%">

    <div class="container rounded p-3 mb-4 bg-primary text-white">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            User Data
        </h2>
    </div>

    <div class="container rounded bg-white p-3" >
        
                <div class="card-header">Users</div>

                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">num</th>
                            <th scope="col">user_id</th>
                            <th scope="col">nama</th>
                            <th scope="col">role</th>
                            <th scope="col">email</th>
                            <th scope="col">virtual_account</th>
                            <th scope="col">created_at</th>
                            <th scope="col">action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th scope="row"><?php echo e($users->firstItem()+$loop->index); ?></th>
                        <td><?php echo e($user->user_id); ?></td>
                        <td><?php echo e($user->nama_depan); ?> <?php echo e($user->nama_belakang); ?></td>
                        <td><?php echo e($user->role); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->virtual_account); ?></td>
                        <td>
                            <?php if($user->created_at==NULL): ?>
                            <span class="text-danger">No Date Set</span>
                            <?php else: ?>
                            <?php echo e($user->created_at); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(url('admin/users/details/'.$user->user_id)); ?>" class="btn btn-info">Details</a>
                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($users->links()); ?>

            
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.navbar.adminSB', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/admin/users/users.blade.php ENDPATH**/ ?>