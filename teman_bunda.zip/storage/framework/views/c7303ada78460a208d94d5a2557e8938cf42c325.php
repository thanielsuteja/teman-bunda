

<?php $__env->startSection('content'); ?>
<div class="container rounded border border-dark bg-dark p-5" style="margin-left:20%; margin-top:5%; height:50%">

    <div class="container rounded p-3 mb-4 bg-primary text-white">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Add New Profession
        </h2>
    </div>

    <div class="container rounded bg-white p-3">
        
        <div class="card-header">Data Input</div>

            <div class="form-group">
                <form action="<?php echo e(route('adm.professions.add')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <div class="mb-3">
                            <label>Profession Name</label>
                            <input type="text" name="profession_name" class="form-control">
                            <?php $__errorArgs = ['profession_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="mb-3">
                            <label>Profession Description</label>
                            <textarea name="profession_desc" class="form-control"></textarea>
                            <?php $__errorArgs = ['profession_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <a href="<?php echo e(url('admin/professions')); ?>" class="btn btn-danger">Cancel</a>
                    <button type="submit" class="btn btn-success">Add Profession</button>
                </form>
            </div>

            
    </div>
    
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar.adminSB', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/admin/profession/add_profession.blade.php ENDPATH**/ ?>