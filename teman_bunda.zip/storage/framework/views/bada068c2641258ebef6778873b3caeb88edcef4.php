
<?php $__env->startSection('title','Review User | Teman Bunda'); ?>
<?php echo $__env->make('layout.navbar.navbar-caretaker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.sidebar.sidebar-caretaker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<style>
    body {
        background-color: #efefef;
    }

    table {
        width: 100%;
    }

    p {
        margin-bottom: 0.3rem;
    }

    .card-review {
        background: #E9E9E9;
        border-radius: 16px;
        margin-bottom: 10px;
        padding: 21px 24px;
    }
</style>

<div class="container col-xxl-12 px-5">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card mb-2 shadow" style="border-radius: 20px; overflow: 0; margin-top: 90px;">
                <div class="card-header bg-temanbunda d-flex align-items-center p-0" style="height: 107px; overflow: 0; border-top-right-radius: 20px; border-top-left-radius: 20px">
                    <div class="row">
                        <div class="col-1 d-flex align-items-center">
                            <a href="<?php echo e(url()->previous()); ?>" class="text-decoration-none fw-bold" style="color: black;">
                                <i class="bi bi-chevron-left ps-3" style="font-size: 36px; height: 36; width: 36;"></i>
                            </a>
                        </div>
                        <div class="col">
                            <h2 class="m-0 ms-5"><?php echo e($user->nama_depan); ?> <?php echo e($user->nama_belakang); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="card-body mx-5" style=" min-height: 532px;">
                    <div class="row px-4" style="margin-top: -50px;">
                        <div class="col-9">
                            <?php for($i = 1; $i < 6; $i++): ?> <?php if($user->meanRating >= $i): ?>
                                <i class="bi-star-fill" style="color: #FF8A00; font-size: 14px;"></i>
                                <?php elseif(($i - $user->meanRating) >= 1): ?>
                                <i class="bi-star" style="color: #FF8A00; font-size: 14px;"></i>
                                <?php elseif(fmod($user->meanRating, 1) != 0): ?>
                                <i class="bi-star-half" style="color: #FF8A00; font-size: 14px;"></i>
                                <?php endif; ?>
                                <?php endfor; ?>
                                <span class="ps-4" style="font-size: 20px;">
                                    <?php echo e($user->JobOffers->reduce(function($total, $jobOffer) {
                                    return $total + ($jobOffer->ReviewUser == null ? 0 : 1);
                                })); ?> ulasan
                                </span>
                                <div class="row pb-3" style="padding-top: 11px;">
                                    <div class="col-md-6 row">
                                        <div class="col-md-6">
                                            <p class="text-808080">ID User</p>
                                        </div>
                                        <div class="col-md-6">
                                            <p><?php echo e($user->user_id); ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6 row">
                                        <div class="col-md-6">
                                            <p class="text-808080">Aktif sejak</p>
                                        </div>
                                        <div class="col-md-6">
                                            <p><?php echo e(date('d/m/Y', strtotime($user->created_at))); ?></p>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <div class="col-3" style="margin-top: -95px;">
                            <?php if($user->profile_img_path != null): ?>
                            <img src="<?php echo e(asset('storage/foto_profil/'.$user->profile_img_path)); ?>" class="profile-pic-lg border">
                            <?php else: ?>
                            <img src="<?php echo e(asset('img/no-profile.png')); ?>" class="profile-pic-lg border">
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php $__currentLoopData = $user->JobOffers()->has('ReviewCaretaker')->orderBy('job_id', 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobOffer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-review mx-3 ">
                        <div class="d-flex">
                            <div class="">
                                <?php if($jobOffer->Caretaker->User->profile_img_path != null): ?>
                                <img src="<?php echo e(asset('storage/foto_profil/'.$jobOffer->Caretaker->User->profile_img_path)); ?>" style="border-radius: 50%; object-fit: cover; width: 69px; height: 69px">
                                <?php else: ?>
                                <img src="<?php echo e(asset('img/no-profile.png')); ?>" style="border-radius: 50%; object-fit: cover; width: 69px; height: 69px">
                                <?php endif; ?>
                            </div>
                            <div class="ms-3">
                                <p class="m-0 fw-bold"><?php echo e($jobOffer->Caretaker->User->nama_depan); ?> <?php echo e($jobOffer->Caretaker->User->nama_belakang); ?></p>
                                <div class="d-flex">
                                    <div class="me-2">
                                        <?php for($i = 1; $i < 6; $i++): ?> <?php if($jobOffer->ReviewCaretaker->review_rating >= $i): ?>
                                            <i class="bi-star-fill" style="color: #FFDE59; font-size: 14px;"></i>
                                            <?php elseif(($i - $jobOffer->ReviewCaretaker->review_rating) >= 1): ?>
                                            <i class="bi-star" style="color: #FFDE59; font-size: 14px;"></i>
                                            <?php elseif(fmod($jobOffer->ReviewCaretaker->review_rating, 1) != 0): ?>
                                            <i class="bi-star-half" style="color: #FFDE59; font-size: 14px;"></i>
                                            <?php endif; ?>
                                            <?php endfor; ?>
                                    </div>
                                    <span class="text-secondary">
                                        <?php echo e(\Carbon\Carbon::parse($jobOffer->created_at)->diffForHumans()); ?>

                                    </span>
                                </div>
                                <p><?php echo e($jobOffer->ReviewCaretaker->review_content); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/caretaker/profil-user.blade.php ENDPATH**/ ?>