
<?php echo $__env->make('layout.navbar-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<div class="container main col-xxl-12 px-5">
    <div class="row">
        <div class="col-md-8 offset-md-2 text-center">
            <div class="card  mb-5">
                <div class="card-header bg-whitesmoke">
                    Filter
                    <select name="filter_profesi" id="">
                        <option value="">Profesi</option>
                        <option value="">asu</option>
                    </select>
                    <select name="filter_area" id="">
                        <option value="">Area</option>
                        <option value="">asu</option>
                    </select>

                </div>
                <div class="card-body">
                    <div class="card bg-whitesmoke border-2">
                        <div class="class-body">
                            <h5 class="card-title">Mia Damae</h5>
                            <p class="card-text">Aku bisa nyuci masak rawat bayi kamu ampe mampi. Dulu pernah kerja di Binus kobek-kobek sebuah big mump dari Pak Asyo</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/cari-caretaker.blade.php ENDPATH**/ ?>