
<?php $__env->startSection('title','Cari Caretaker | Teman Bunda'); ?>
<?php echo $__env->make('layout.navbar.navbar-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.sidebar.sidebar-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<style>
    body {
        background-color: #efefef;
    }
</style>
<script>
    $(document).ready(function() {
        $('#filter_mengasuh').on('change', function() {
            var mengasuh = $(this).val();
            var url = window.location.protocol + '//' + window.location.host + window.location.pathname;
            var query = new URLSearchParams(window.location.search);
            query.set('mengasuh', mengasuh);
            window.location.href = url + '?' + query.toString();
        });
        $('#filter_area').on('change', function() {
            var area = $(this).val();
            var url = window.location.protocol + '//' + window.location.host + window.location.pathname;
            var query = new URLSearchParams(window.location.search);
            query.set('area', area);
            window.location.href = url + '?' + query.toString();
        });
    });
</script>
<script>
    $(document).ready(function() {
        $('#filter_mengasuh').on('change', function() {
            var mengasuh = $(this).val();
            var url = window.location.protocol + '//' + window.location.host + window.location.pathname;
            var query = new URLSearchParams(window.location.search);
            query.set('mengasuh', mengasuh);
            window.location.href = url + '?' + query.toString();
        });
    });
</script>
<!-- <script type="text/javascript">
    $('ul.pagination').hide();
    $(function() {
        $('.scrolling-pagination').jscroll({
            autoTrigger: true,
            padding: 0,
            nextSelector: '.pagination li.active + li a',
            contentSelector: 'div.scrolling-pagination',
            callback: function() {
                $('ul.pagination').remove();
            }
        });
    });
</script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jscroll/2.4.1/jquery.jscroll.min.js"></script>

<div class="container main col-xxl-12 px-5 mt-0">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card shadow mb-4" style="border-radius: 20px; overflow: hidden; margin-top: 90px;">
                <div class="card-header bg-temanbunda d-flex align-items-center py-4">
                    <label class="h5 px-3 m-0">Cari berdasarkan</label>
                    <div class="form-floating d-inline-block pe-3" style="width: 200px;">
                        <select name="filter_mengasuh" id="filter_mengasuh" class="form-select rounded-input">
                            <option selected></option>
                            <?php $__currentLoopData = $profesi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e(request()->get('mengasuh') == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="filter_mengasuh">Mengasuh</label>
                    </div>
                    <div class="form-floating d-inline-block me-3" style="width: 200px;">
                        <select name="filter_area" id="filter_area" class="form-select rounded-input">
                            <option selected></option>
                            <?php $__currentLoopData = $area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e(request()->get('area') == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="filter_area">Area (Kecamatan)</label>
                    </div>
                    <div class="d-inline-block ps-4 pe-3">
                        <?php if(request()->has('mengasuh') || request()->has('area')): ?>
                        <a href="<?php echo e(route('cari-caregiver')); ?>" class="nav-link link-dark text-decoration-none p-2" data-bs-toggle="tooltip" data-placement="bottom" title="Hapus filter" style="border-radius: 10px;">
                            <i class="bi bi-x-circle m-0" style="font-size: 30;"></i>
                        </a>
                        <?php else: ?>
                        <a href="<?php echo e(route('cari-caregiver')); ?>" class="nav-link link-dark text-decoration-none p-2 disabled" data-bs-toggle="tooltip" data-placement="right" title="Hapus filter" style="border-radius: 10px;">
                            <i class="bi bi-x-circle m-0" style="font-size: 30;"></i>
                        </a>
                        <?php endif; ?>
                    </div>
                    <div class="dropdown d-inline-block pe-4">
                        <button type="button" class="nav-link link-dark text-decoration-none p-2 bg-temanbunda border-0" id="dropdown_filter" data-bs-toggle="dropdown" aria-expanded="false" aria-haspopup="true" data-placement="bottom" title="Urutkan berdasarkan" style="border-radius: 10px;">
                            <i class="bi bi-sort-down m-0" style="font-size: 30;"></i>
                        </button>
                        <ul class="dropdown-menu text-small" aria-labelledby="dropdown_filter">
                            <li><a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['sort' => 'rating-tertinggi'])); ?>">Rating tertinggi</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['sort' => 'harga-terendah'])); ?>">Harga terendah</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['sort' => 'umur-termuda'])); ?>">Umur termuda</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['sort' => 'umur-tertua'])); ?>">Umur tertua</a></li>
                        </ul>
                    </div>
                </div>
                <div class="card-body" style="min-height: 532px;">
                    <div class="scrolling-pagination">
                        <?php $__empty_1 = true; $__currentLoopData = $caretaker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $care): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="/user/info-caregiver/<?php echo e($care->caretaker_id); ?>" class="text-decoration-none" style="color: black;">
                            <div class="card border-2 mx-5 my-3 zoom" style="background-color: #f3f3f3; border-radius: 10px; overflow: hidden; min-height: 190px;">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-auto px-4 text-center">
                                            <?php if($care->User->profile_img_path != null): ?>
                                            <img src="<?php echo e(asset('storage/foto_profil/'.$care->User->profile_img_path)); ?>" class="profile-pic border border-5">
                                            <?php else: ?>
                                            <img src="<?php echo e(asset('img/no-profile.png')); ?>" class="profile-pic border border-5">
                                            <?php endif; ?>
                                            <div class="justify-content-center d-flex pt-2">
                                                <?php for($i = 1; $i < 6; $i++): ?> <?php if($care->meanRating >= $i): ?>
                                                    <i class="bi-star-fill" style="color: #FFDE59;"></i>
                                                    <?php elseif(($i - $care->meanRating) >= 1): ?>
                                                    <i class="bi-star" style="color: #FFDE59;"></i>
                                                    <?php elseif(fmod($care->meanRating, 1) != 0): ?>
                                                    <i class="bi-star-half" style="color: #FFDE59;"></i>
                                                    <?php endif; ?>
                                                    <?php endfor; ?>
                                            </div>
                                            <div class="row text-center">
                                                <p class="m-0">
                                                    <?php if($care->countReviewUser == 0): ?>
                                                    0 ulasan
                                                    <?php else: ?>
                                                    <?php echo e($care->countReviewUser); ?> ulasan
                                                    <?php endif; ?>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="col-md-9 ps-0">
                                            <div class="row pb-1 pt-1">
                                                <div class="col">
                                                    <h4 class="card-title m-0 py-1" style="display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden;">
                                                        <?php echo e($care->User->nama_depan); ?> <?php echo e($care->User->nama_belakang); ?>, <?php echo e($care->age); ?>

                                                    </h4>
                                                </div>
                                                <?php if($care->takut_anjing == 0): ?>
                                                <div class="col-1">
                                                    <button type="button" data-bs-toggle="tooltip" data-bs-placement="right" title="Dapat bekerja dengan kehadiran binatang peliharaan" style="border: none; padding: 0; background: none; margin-top: 5px;">
                                                        <i class="fas fa-paw m-0" style="font-size: 24;"></i>
                                                    </button>
                                                </div>
                                                <?php endif; ?>
                                                <div class="col-1">
                                                    <?php if($care->pengawasan_kamera == 1): ?>
                                                    <button type="button" data-bs-toggle="tooltip" data-bs-placement="right" title="Dapat bekerja di bawah pengawasan kamera" style="border: none; padding: 0; background: none; margin-top: 5px;">
                                                        <i class="bi bi-camera-video-fill m-0" style="font-size: 24;"></i>
                                                    </button>
                                                    <?php else: ?>
                                                    <button type="button" data-bs-toggle="tooltip" data-bs-placement="right" title="Tidak dapat bekerja di bawah pengawasan kamera" style="border: none; padding: 0; background: none; margin-top: 5px;">
                                                        <i class="bi bi-camera-video-off-fill m-0" style="font-size: 24;"></i>
                                                    </button>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-1">
                                                    <?php if($care->dokumen_vaksin_path == null && $care->dokumen_ijazah_path == null && $care->dokumen_psikotes_path == null && $care->dokumen_skck_path == null): ?>
                                                    <button type="button" data-bs-toggle="tooltip" data-bs-placement="left" title="Belum memasukkan dokumen pribadi" style="border: none; padding: 0; background: none; margin-top: 5px;">
                                                        <i class="bi bi-file-earmark-x-fill m-0" style="font-size: 24px;"></i>
                                                    </button>
                                                    <?php else: ?>
                                                    <button type="button" data-bs-toggle="tooltip" data-bs-placement="left" title="<?php echo e($care->dokumen_vaksin_path != null ? 'Sertifikat Vaksinasi' : ''); ?> <?php echo e($care->dokumen_ijazah_path != null ? 'Ijazah' : ''); ?> <?php echo e($care->dokumen_psikotes_path != null ? 'Psikotes' : ''); ?> <?php echo e($care->dokumen_skck_path != null ? 'SKCK' : ''); ?>" style="border: none; padding: 0; background: none; margin-top: 5px;">
                                                        <i class="bi bi-file-earmark-check-fill m-0" style="font-size: 24;"></i>
                                                    </button>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row" style="font-size: 16px;">
                                                <div class="col">
                                                    <p class="m-0">Harapan Rp<?php echo e(number_format($care->cost_per_hour, 0, "," ,".")); ?>,00 per jam</p>
                                                    <p class="m-0" style="display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden;">Mengasuh
                                                        <?php $__currentLoopData = $care->ProfessionCaretakerRelation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mengasuh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($mengasuh->Profession->profession_name); ?>,
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </p>
                                                </div>
                                                <div class="col">
                                                    <p class="m-0">
                                                        <?php echo e(ucwords(strtolower($care->User->kabupaten))); ?>

                                                    </p>
                                                    <p class="m-0" style="display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden;">
                                                        <?php $__currentLoopData = $care->RegionCaretakerRelation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e(ucwords(strtolower($area->Region->region_name))); ?>,
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="row mt-2" style="font-size: 16px; padding-left: 12px;">
                                                <p class="line-clamp text-808080 mb-0"><?php echo e($care->deskripsi_caretaker); ?>...</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="container row justify-content-center text-center">
                            <img src="<?php echo e(asset('img/happy_astro_404.png')); ?>" class="" style="width: 550;">
                            <p class="fw-normal text-808080">Oops! Kamu tidak dapat menemukan caregiver yang kamu cari</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jscroll/2.4.1/jquery.jscroll.min.js"></script>
<script>
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/user/cari-caretaker.blade.php ENDPATH**/ ?>