

<?php $__env->startSection('content'); ?>
<div class="container rounded border border-dark bg-dark p-5" style="margin-left:20%; margin-top:5%; height:50%;">

    <div class="container rounded p-3 mb-4 text-white">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Transaction Data
        </h2>
    </div>

    <div class="container rounded bg-white p-3" style="min-width: 1400px;">

        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('success')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
            </button>
        </div>
        <?php endif; ?>

        <div class="card-header">Transactions</div>

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">num</th>
                    <th scope="col">transaction_id</th>
                    <th scope="col">status</th>
                    <th scope="col">job_id</th>
                    <th scope="col">ammount</th>
                    <th scope="col">due date</th>
                    <th scope="col">payment_date</th>
                    <th scope="col">bank_account</th>
                    <th scope="col">virtual_account</th>
                    <th scope="col">created_at</th>
                    <th scope="col">updated_at</th>
                    <th scope="col">actions</th>

                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($transactions->firstItem()+$loop->index); ?></th>
                    <td><?php echo e($transaction->transaction_id); ?></td>
                    <td><?php echo e($transaction->transaction_status); ?></td>
                    <td><?php echo e($transaction->job_id); ?></td>
                    <td><?php echo e($transaction->transaction_amount); ?></td>
                    <td><?php echo e($transaction->transaction_due); ?></td>
                    <td>
                        <?php if($transaction->payment_date==NULL): ?>
                        <span class="text-danger">unpaid</span>
                        <?php else: ?>
                        <?php echo e($transaction->payment_date); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e($transaction->bank_account); ?></td>
                    <td><?php echo e($transaction->virtual_account); ?></td>
                    <td>
                        <?php if($transaction->created_at==NULL): ?>
                        <span class="text-danger">No Date Set</span>
                        <?php else: ?>
                        <?php echo e($transaction->created_at); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($transaction->updated_at==NULL): ?>
                        <span class="text-danger">No Date Set</span>
                        <?php else: ?>
                        <?php echo e($transaction->updated_at); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($transaction->transaction_status=="menunggu"): ?>
                        <a role="button" class="btn btn-primary btn-sm" onclick="return confirm('Finish Payment ?')" href="/admin/transactions/finish/<?php echo e($transaction->transaction_id); ?>">Finish Payment</a>
                        <?php elseif($transaction->transaction_status == "terbayar"): ?>
                        <a role="button" class="btn btn-secondary btn-sm" onclick="return confirm('Verify Payment ?')" href="/admin/transactions/verify/<?php echo e($transaction->transaction_id); ?>">Verify Payment</a>
                        <?php else: ?>
                        <a href="#" class="btn btn-success btn-sm disabled">Payment Verified</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($transactions->links()); ?>


    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.navbar.adminSB', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/admin/transaction/transactions.blade.php ENDPATH**/ ?>