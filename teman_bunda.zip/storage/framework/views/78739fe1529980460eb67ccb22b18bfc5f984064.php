

<?php $__env->startSection('content'); ?>
<div class="container rounded border border-dark bg-dark p-5" style="margin-left:20%; margin-top:5%; height:50%">

    <div class="container rounded p-3 mb-4 bg-primary text-white">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Job Offer Data
        </h2>
    </div>

    <div class="container rounded bg-white p-3" >
        
                <div class="card-header">Job Offers</div>

                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">num</th>
                            <th scope="col">job_id</th>
                            <th scope="col">job_status</th>
                            <th scope="col">user_id</th>
                            <th scope="col">caretaker_id</th>
                            <th scope="col">created_at</th>
                            <th scope="col">updated_at</th>
                            <th scope="col">actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $job_offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th scope="row"><?php echo e($job_offers->firstItem()+$loop->index); ?></th>
                        <td><?php echo e($job_offer->job_id); ?></td>
                        <td><?php echo e($job_offer->job_status); ?></td>
                        <td><?php echo e($job_offer->user_id); ?></td>
                        <td><?php echo e($job_offer->caretaker_id); ?></td>
                        <td>
                            <?php if($job_offer->created_at==NULL): ?>
                            <span class="text-danger">No Date Set</span>
                            <?php else: ?>
                            <?php echo e($job_offer->created_at); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($job_offer->updated_at==NULL): ?>
                            <span class="text-danger">No Date Set</span>
                            <?php else: ?>
                            <?php echo e($job_offer->updated_at); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(url('admin/job_offers/details/'.$job_offer->job_id)); ?>" class="btn btn-info">Details</a>
                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($job_offers->links()); ?>

            
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.navbar.adminSB', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/admin/job_offer/job_offers.blade.php ENDPATH**/ ?>