
<?php $__env->startSection('title','Cari Caretaker | Teman Bunda'); ?>
<?php echo $__env->make('layout.navbar.navbar-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.sidebar.sidebar-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<style>
    body {
        background-color: #efefef;
    }

    table {
        width: 100%;
    }

    p {
        margin-bottom: 0.3rem;
    }
</style>

<div class="container col-xxl-12 px-5">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card shadow mb-4" style="border-radius: 20px; overflow: hidden; margin-top: 90px;">
                <div class="card-header bg-temanbunda d-flex align-items-center p-0" style="height: 107px;">
                    <div class="row">
                        <div class="col-1 d-flex align-items-center">
                            <a href="<?php echo e(route('cari-caregiver')); ?>" class="text-decoration-none fw-bold" style="color: black;">
                                <i class="bi bi-chevron-left ps-3" style="font-size: 36px; height: 36; width: 36;"></i>
                            </a>
                        </div>
                        <div class="col">
                            <h2 class="m-0 ms-5"><?php echo e($care->User->nama_depan); ?> <?php echo e($care->User->nama_belakang); ?><span class="text-808080">, <?php echo e($care->age); ?></span></h2>
                        </div>
                    </div>
                </div>
                <div class="card-body mx-5" style=" min-height: 532px;">
                    <div class="row px-4" style="margin-top: -50px;">
                        <div class="col-9">
                            <?php for($i = 1; $i < 6; $i++): ?> <?php if($care->meanRating >= $i): ?>
                                <i class="bi-star-fill" style="color: #FF8A00; font-size: 14px;"></i>
                                <?php elseif(($i - $care->meanRating) >= 1): ?>
                                <i class="bi-star" style="color: #FF8A00; font-size: 14px;"></i>
                                <?php elseif(fmod($care->meanRating, 1) != 0): ?>
                                <i class="bi-star-half" style="color: #FF8A00; font-size: 14px;"></i>
                                <?php endif; ?>
                                <?php endfor; ?>
                                <span class="ps-4" style="font-size: 20px;">
                                    <?php if($care->countReviewUser == 0): ?>
                                    0 ulasan
                                    <?php else: ?>
                                    <?php echo e($care->countReviewUser); ?> ulasan
                                    <?php endif; ?>
                                </span>
                                <div class="row pt-3">
                                    <div class="col-3 text-center">
                                        <?php if($care->takut_anjing == 0): ?>
                                        <button type="button" class="me-3" data-bs-toggle="tooltip" data-bs-placement="right" title="Dapat bekerja dengan keberadaan hewan peliharaan" style="border: none; padding: 0; background: none; margin-top: 5px;">
                                            <i class="fas fa-paw m-0" style="font-size: 24;"></i>
                                        </button>
                                        <?php else: ?>
                                        <button type="button" class="me-3" data-bs-toggle="tooltip" data-bs-placement="right" title="Tidak dapat bekerja dengan keberadaan hewan peliharaan" style="border: none; padding: 0; background: none; margin-top: 5px;">
                                            <i class="fas fa-paw text-muted m-0" style="font-size: 24;"></i>
                                        </button>
                                        <?php endif; ?>

                                        <?php if($care->pengawasan_kamera == 1): ?>
                                        <button type="button" data-bs-toggle="tooltip" data-bs-placement="right" title="Dapat bekerja di bawah pengawasan kamera" style="border: none; padding: 0; background: none; margin-top: 5px;">
                                            <i class="bi bi-camera-video-fill m-0" style="font-size: 24;"></i>
                                        </button>
                                        <?php else: ?>
                                        <button type="button" data-bs-toggle="tooltip" data-bs-placement="right" title="Tidak dapat bekerja di bawah pengawasan kamera" style="border: none; padding: 0; background: none; margin-top: 5px;">
                                            <i class="bi bi-camera-video-off-fill m-0" style="font-size: 24;"></i>
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-8 row align-items-center">
                                        <div class="col-auto">
                                            <p class="text-808080">ID Caregiver</p>
                                        </div>
                                        <div class="col-auto"><?php echo e($care->caretaker_id); ?></div>
                                    </div>
                                </div>
                        </div>
                        <div class="col-3 mb-2" style="margin-top: -45px;">
                            <?php if($care->User->profile_img_path != null): ?>
                            <img src="<?php echo e(asset('storage/foto_profil/'.$care->User->profile_img_path)); ?>" class="profile-pic-lg border">
                            <?php else: ?>
                            <img src="<?php echo e(asset('img/no-profile.png')); ?>" class="profile-pic-lg border">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row pt-2">
                        <div class="col-md-6 pe-0" style="border-right: 1px solid #9e9e9e;">
                            <div class="row">
                                <div class="col-md-5">
                                    <p class="text-808080">Jenis kelamin</p>
                                </div>
                                <div class="col-md-7">
                                    <p><?php echo e(ucfirst($care->User->jenis_kelamin)); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <p class="text-808080">Harapan tarif</p>
                                </div>
                                <div class="col-md-7">
                                    <p>Rp<?php echo e(number_format($care->cost_per_hour, 0, ",", ".")); ?>,00</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <p class="text-808080">Area</p>
                                </div>
                                <div class="col-md-7">
                                    <p>
                                        <?php $__currentLoopData = $care->RegionCaretakerRelation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e(ucwords(strtolower($area->Region->region_name))); ?> <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <p class="text-808080">Mengasuh</p>
                                </div>
                                <div class="col-md-7">
                                    <p>
                                        <?php $__currentLoopData = $care->ProfessionCaretakerRelation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mengasuh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($mengasuh->Profession->profession_name); ?> <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-5">
                                    <p class="text-808080">Aktif sejak</p>
                                </div>
                                <div class="col-md-7">
                                    <p><?php echo e(date('d/m/Y', strtotime($care->created_at))); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <p class="text-808080">Tipe caregiver</p>
                                </div>
                                <div class="col-md-7">
                                    <p><?php echo e($care->tipe_caretaker); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <p class="text-808080">Edukasi</p>
                                </div>
                                <div class="col-md-7">
                                    <p><?php echo e($care->edukasi); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <p class="text-808080">Dokumen</p>
                                </div>
                                <div class="col-md-7">
                                    <?php if($care->dokumen_vaksin_path == null && $care->dokumen_psikotes_path == null && $care->dokumen_ijazah_path == null && $care->dokumen_skck_path == null): ?>
                                    <p>Tidak ada dokumen</p>
                                    <?php endif; ?>
                                    <p>
                                        <?php if($care->dokumen_vaksin_path != null): ?>
                                        Sertifikat Vaksinasi
                                        <br>
                                        <?php endif; ?>
                                        <?php if($care->dokumen_psikotes_path != null): ?>
                                        Berkas Psikotes
                                        <br>
                                        <?php endif; ?>
                                        <?php if($care->dokumen_ijazah_path != null): ?>
                                        Ijazah
                                        <br>
                                        <?php endif; ?>
                                        <?php if($care->dokumen_skck_path != null): ?>
                                        SKCK
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row pt-3">
                        <div class="col-md-auto ps-2" style="width: 145px;">
                            <p class="text-808080">Tentang</p>
                        </div>
                        <div class="col-md">
                            <p><?php echo e($care->deskripsi_caretaker); ?></p>
                        </div>
                    </div>
                    <hr class="mt-2 mb-3">
                    <div class="row pt-1">
                        <p class="text-808080">Ulasan Untuk Caregiver Ini</p>
                    </div>
                    <div class="d-flex pt-1 justify-content-center">
                        <div class="card card-body py-2 px-4" style="background-color: #f6f6f6; border-radius: 5px;">
                            <?php $__currentLoopData = $care->JobOffers()->has('ReviewUser')->orderBy('job_id', 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row py-2 border-top border-bottom" style="min-height: 118px;">
                                <div class="col-md-auto px-3">
                                    <?php if($job->User->profile_img_path != null): ?>
                                    <img src="<?php echo e(asset('storage/foto_profil/'.$job->User->profile_img_path)); ?>" style="border-radius: 50%; object-fit: cover; width: 69px; height: 69px">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('img/no-profile.png')); ?>" style="border-radius: 50%; object-fit: cover; width: 69px; height: 69px">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md ps-0 pe-3">
                                    <p class="m-0 fw-bold"><?php echo e($job->User->nama_depan); ?> <?php echo e($job->User->nama_belakang); ?></p>
                                    <div class="d-flex">
                                        <div class="me-2">
                                            <?php for($i = 1; $i < 6; $i++): ?> <?php if($job->ReviewUser->review_rating >= $i): ?>
                                                <i class="bi-star-fill" style="color: #FFDE59; font-size: 14px;"></i>
                                                <?php elseif(($i - $job->ReviewUser->review_rating) >= 1): ?>
                                                <i class="bi-star" style="color: #FFDE59; font-size: 14px;"></i>
                                                <?php elseif(fmod($job->ReviewUser->review_rating, 1) != 0): ?>
                                                <i class="bi-star-half" style="color: #FFDE59; font-size: 14px;"></i>
                                                <?php endif; ?>
                                                <?php endfor; ?>
                                        </div>
                                        <span class="text-secondary">
                                            <?php echo e(\Carbon\Carbon::parse($job->created_at)->diffForHumans()); ?>

                                        </span>
                                    </div>
                                    <p><?php echo e($job->ReviewUser->review_content); ?></p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="row justify-content-end pt-4">
                        <a href="/user/buat-penawaran/<?php echo e($care->caretaker_id); ?>" class="btn bg-temanbunda fw-bold d-flex align-items-center justify-content-center" style="width: 235px; height: 58px;">Buat Penawaran</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/user/caretaker-info.blade.php ENDPATH**/ ?>