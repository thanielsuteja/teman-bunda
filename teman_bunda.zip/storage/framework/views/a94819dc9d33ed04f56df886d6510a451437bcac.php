

<?php $__env->startSection('content'); ?>
    <div class="container rounded border border-dark bg-dark p-5" style="margin-left:20%; margin-top:5%; height:50%">

        <div class="container rounded p-3 mb-4 bg-primary text-white">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Region Data
            </h2>
        </div>

        <div class="container rounded bg-white p-3">
            

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session('success')); ?></strong> 
                            <button type="button" class="btn-close"  data-bs-dismiss="alert" aria-label="Close">
                            </button>
                        </div>
                    <?php endif; ?>

                    <div class="card-header">Regions</div>

                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col"></th>
                                <th scope="col"></th>
                                <th scope="col"></th>
                                <th scope="col"></th>
                                <th scope="col"></th>
                                <th scope="col"><a href="<?php echo e(url('/admin/regions/new')); ?>" class="btn btn-info">Add New Region</a></th>
                            </tr>
                            <tr>
                                <th scope="col">num</th>
                                <th scope="col">region_id</th>
                                <th scope="col">region_name</th>
                                <th scope="col">created_at</th>
                                <th scope="col">updated_at</th>
                                <th scope="col">action</th>
                            </tr>
                            
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <th scope="row"><?php echo e($regions->firstItem()+$loop->index); ?></th>
                            <td><?php echo e($region->region_id); ?></td>
                            <td><?php echo e($region->region_name); ?></td>
                            <td>
                                <?php if($region->created_at==NULL): ?>
                                <span class="text-danger">No Date Set</span>
                                <?php else: ?>
                                <?php echo e($region->created_at); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($region->updated_at==NULL): ?>
                                <span class="text-danger">No Date Set</span>
                                <?php else: ?>
                                <?php echo e($region->updated_at); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(url('admin/regions/edit/'.$region->region_id)); ?>" class="btn btn-info">Edit</a>
                                <a href="<?php echo e(url('admin/regions/delete/'.$region->region_id)); ?>" class="btn btn-danger">Delete</a>
                            </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                    <?php echo e($regions->links()); ?>

                    
                    
                
            
        </div>
        
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.navbar.adminSB', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/admin/region/regions.blade.php ENDPATH**/ ?>