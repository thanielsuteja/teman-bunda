

<?php $__env->startSection('content'); ?>
<div class="container rounded border border-dark bg-dark p-5" style="margin-left:20%; margin-top:5%; height:50%">

<div class="container rounded p-3 mb-4 bg-primary text-white">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Welcome
    </h2>
</div>

<div class="container rounded bg-white p-3">
    
    <div class="card-header">Logged in as admin: <?php echo e(Auth::user()->nama_depan); ?> <?php echo e(Auth::user()->nama_belakang); ?>, UID: <?php echo e(Auth::user()->user_id); ?> </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.navbar.adminSB', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/admin/index.blade.php ENDPATH**/ ?>