

<?php $__env->startSection('content'); ?>
<div class="container rounded border border-dark bg-dark p-5" style="margin-left:20%; margin-top:5%; margin-bottom:5%; height:50%">

    <div class="container p-3 mb-4 bg-primary text-white">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Edit User Data
        </h2>
    </div>

    <div class="container rounded bg-white p-3">

        <div class="card-header">Edit Admin Profile</div>
        <?php ($cur_id = Auth::user()->user_id); ?>
        <div class="form-group">
            <form action="<?php echo e(url('/admin/profile/update-profile/'.$cur_id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">

                    <div class="mb-3">
                        <label>nama depan</label>
                        <input type="text" name="nama_depan" class="form-control" value="<?php echo e(Auth::user()->nama_depan); ?>">
                        <?php $__errorArgs = ['nama_depan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label>nama belakang</label>
                        <input type="text" name="nama_belakang" class="form-control" value="<?php echo e(Auth::user()->nama_belakang); ?>">
                        <?php $__errorArgs = ['nama_belakang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label>profile img</label>
                        <input type="hidden" name="old_image" value="<?php echo e(Auth::user()->profile_img_path); ?>">
                        <input type="file" name="profile_img_path" id="profile_img_path" class="form-control" value="<?php echo e(Auth::user()->profile_img_path); ?>">
                        <?php $__errorArgs = ['profile_img_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <img src="<?php echo e(asset(Auth::user()->profile_img_path)); ?>" style="height:70px;width:70px">
                    </div>

                    <div class="mb-3">
                        <label>nomor telepon</label>
                        <input type="text" name="nomor_telepon" class="form-control" value="<?php echo e(Auth::user()->nomor_telepon); ?>">
                        <?php $__errorArgs = ['nomor_telpon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label>alamat</label>
                        <input type="text" name="alamat" class="form-control" value="<?php echo e(Auth::user()->alamat); ?>">
                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>
                <a href="<?php echo e(url('/admin/profile')); ?>" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-success">Edit Profile</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar.adminSB', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/admin/profile/AdmProfile_edit.blade.php ENDPATH**/ ?>