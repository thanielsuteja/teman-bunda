
<?php $__env->startSection('title', 'Terima kasih!'); ?>
<?php echo $__env->make('layout.navbar.navbar-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<style>
    body {
        overflow-x: hidden;
    }
</style>
<div class="row justify-content-center">
    <div class="col-5 border-2 border-start border-end px-5" style="min-height: 632px; margin-top: 97px;">
        <p class="display-4">Terima kasih sudah bertransaksi bersama Teman Bunda</p>
        <div class="row justify-content-center" style="margin-top: 260px;">
            <a href="<?php echo e(route('user.home')); ?>" class="btn bg-temanbunda py-3 px-5" style="width: 50%; font-size: 18px;" role="button">Kembali ke Beranda</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/user/terima-kasih.blade.php ENDPATH**/ ?>