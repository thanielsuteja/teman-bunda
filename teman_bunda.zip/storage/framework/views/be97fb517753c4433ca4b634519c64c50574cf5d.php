<footer class="footer mt-auto py-3 bg-secondary">
    <div class="container">
        <span class="text-white">&copy; Teman Bunda 2021</span>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/layout/footer.blade.php ENDPATH**/ ?>