

<?php $__env->startSection('content'); ?>
<div class="container rounded border border-dark bg-dark p-5" style="margin-left:20%; margin-top:5%; margin-bottom:5%; height:50%">

    <div class="container p-3 mb-4 bg-primary text-white">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            User Data
        </h2>
    </div>

    <div class="container rounded bg-white p-3">

        <div class="card-header">Displaying caretaker application of User: <?php echo e($caretaker->user->nama_depan); ?> <?php echo e($caretaker->user->nama_belakang); ?> UID: <?php echo e($caretaker->user_id); ?></div>

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Field</th>
                    <th scope="col">Value</th>

                </tr>
            </thead>

            <tbody>

                <tr>
                    <td>caretaker_id</td>
                    <td><?php echo e($caretaker->caretaker_id); ?></td>
                </tr>
                <tr>
                    <td>caretaker_status</td>
                    <td><?php echo e($caretaker->caretaker_status); ?></td>
                </tr>
                <tr>
                    <td>approval_status</td>
                    <td><?php echo e($caretaker->approved); ?></td>
                </tr>
                <tr>
                    <td>user_id</td>
                    <td><?php echo e($caretaker->user_id); ?></td>
                </tr>
                <tr>
                    <td>tipe_caretaker</td>
                    <td><?php echo e($caretaker->tipe_caretaker); ?></td>
                </tr>
                <tr>
                    <td>professions(id)</td>
                    <td>
                        <?php $__currentLoopData = $caretaker->ProfessionCaretakerRelation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Prel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span><?php echo e($Prel->profession_id); ?><span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
                <tr>
                    <td>regions(id)</td>
                    <td>
                        <?php $__currentLoopData = $caretaker->RegionCaretakerRelation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Rrel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span><?php echo e($Rrel->region_id); ?><span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
                <tr>
                    <td>bank_account</td>
                    <td><?php echo e($caretaker->bank_account); ?></td>
                </tr>
                <tr>
                    <td>kode_bank</td>
                    <td><?php echo e($caretaker->kode_bank); ?></td>
                </tr>
                <tr>
                    <td>cost_per_hour</td>
                    <td><?php echo e($caretaker->cost_per_hour); ?></td>
                </tr>
                <tr>
                    <td>umur</td>
                    <td><?php echo e($caretaker->age); ?></td>
                </tr>
                <tr>
                    <td>edukasi</td>
                    <td><?php echo e($caretaker->edukasi); ?></td>
                </tr>
                <tr>
                    <td>deskripsi_caretaker</td>
                    <td><?php echo e($caretaker->deskripsi_caretaker); ?></td>
                </tr>
                <tr>
                    <td>pengawasan_kamera</td>
                    <td>
                        <?php if($caretaker->pengawasan_kamera==1): ?>
                        <span>true</span>
                        <?php else: ?>
                        <span>false</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>takut_anjing</td>
                    <td>
                        <?php if($caretaker->takut_anjing==1): ?>
                        <span>true</span>
                        <?php else: ?>
                        <span>false</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>NIK</td>
                    <td><?php echo e($caretaker->NIK); ?></td>
                </tr>
                <tr>
                    <td>dokumen_vaksin</td>
                    <td><img src="<?php echo e(asset('storage/vaksin/'.$caretaker->dokumen_vaksin_path)); ?>" style="height:70px;width:70px"></td>
                </tr>
                <tr>
                    <td>dokumen_ijazah</td>
                    <td><img src="<?php echo e(asset('storage/ijazah/'.$caretaker->dokumen_ijazah_path)); ?>" style="height:70px;width:70px"></td>
                </tr>
                <tr>
                    <td>dokumen_psikotes</td>
                    <td><img src="<?php echo e(asset('storage/psikotes/'.$caretaker->dokumen_psikotes_path)); ?>" style="height:70px;width:70px"></td>
                </tr>
                <tr>
                    <td>dokumen_skck</td>
                    <td><img src="<?php echo e(asset('storage/skck/'.$caretaker->dokumen_skck_path)); ?>" style="height:70px;width:70px"></td>
                </tr>
                <tr>
                    <td>rating_caretaker</td>
                    <td><?php echo e($caretaker->rating_caretaker); ?></td>
                </tr>
                <tr>
                    <td>created_at</td>
                    <td><?php echo e($caretaker->created_at); ?></td>
                </tr>
                <tr>
                    <td>updated_at</td>
                    <td><?php echo e($caretaker->updated_at); ?></td>
                </tr>
                <tr>
                    <td>actions</td>
                    <td>
                        <?php if($caretaker->approved=="pending"): ?>
                        <!-- <form action="<?php echo e(url('/admin/applications/deny/'.$caretaker->caretaker_id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="approved" class="form-control invisible" style="height:0px; width:0px;" value="denied">
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Deny apllication request ?')">Deny</button>
                        </form> -->
                        <a href="/admin/applications/deny/<?php echo e($caretaker->caretaker_id); ?>" class="btn btn-danger" onclick="return confirm('Deny apllication request ?')">Tolak</a>
                        <!-- <form action="<?php echo e(url('/admin/applications/accept/'.$caretaker->caretaker_id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                            <input type="text" name="user_id" class="form-control invisible" style="height:0px; width:0px;" value="<?php echo e($caretaker->user_id); ?>">
                            <input type="text" name="approved" class="form-control invisible" style="height:0px; width:0px;" value="accepted">
                            <button type="submit" class="btn btn-success" onclick="return confirm('Accept apllication request ?')">Accept</button>
                        </form> -->
                        <a href="/admin/applications/accept/<?php echo e($caretaker->caretaker_id); ?>" class="btn btn-success" onclick="return confirm('Accept apllication request ?')">Izinkan</a>
                        <?php else: ?>
                        <a href="#" class="btn btn-success float-right disabled">No actions available</a>
                        <?php endif; ?>
                    </td>
                </tr>

            </tbody>
        </table>

        <a href="<?php echo e(url('admin/applications')); ?>" class="btn btn-primary float-right">Back</a>
    </div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.navbar.adminSB', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/admin/application/application_details.blade.php ENDPATH**/ ?>