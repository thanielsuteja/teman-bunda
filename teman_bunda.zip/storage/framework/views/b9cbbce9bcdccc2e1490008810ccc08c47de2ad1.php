
<?php $__env->startSection('title','Ulasan Saya | Teman Bunda'); ?>
<?php echo $__env->make('layout.navbar.navbar-caretaker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.sidebar.sidebar-caretaker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        body {
            background-color: #efefef;
        }
    </style>

    <div class="container main col-xxl-12 px-5">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card mb-5" style="border-radius: 20px; overflow: hidden;">
                    <div class="card-header bg-temanbunda d-flex justify-content-between align-items-center py-4">
                        <h3 class="ps-3 fw-bold m-0">Ulasan</h3>
                    </div>
                    <div class="card-body" style="min-height: 532px;">
                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="text-decoration-none" style="color: black;">
                                <div class="card border-2 mx-4 my-2" style="background-color: #f3f3f3; border-radius: 10px; overflow: hidden;">
                                    <div class="card-header d-flex justify-content-between py-3" style="background: #FFEEA8;">
                                        <div><span class="text-808080 me-1">Ulasan dari</span> <?php echo e($review->User->nama_depan); ?> <?php echo e($review->User->nama_belakang); ?></div>
                                        <div><span class="text-808080 me-1">Tanggal kerja</span> <?php echo e(date('d/m/Y', strtotime($review->tanggal_masuk))); ?> - <?php echo e(date('d/m/Y', strtotime($review->tanggal_berakhir))); ?></div>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-3 px-2 text-center">
                                                <?php if($review->User->profile_img_path != null): ?>
                                                    <img src="<?php echo e(asset('storage/foto_profil/'.$review->User->profile_img_path)); ?>" style="border-radius: 50%; object-fit: cover; width: 110px; height: 110px; border: 7px solid #FFE074">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('img/no-profile.png')); ?>" style="border-radius: 50%; object-fit: cover; width: 110px; height: 110px; border: 7px solid #FFE074">
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-9">
                                                <p class="m-0"><span class="text-808080">Order ID</span> <?php echo e($review->job_id); ?></p>
                                                <p class="m-0"><?php echo e($review->judul_pekerjaan); ?></p>
                                                <div>
                                                    <?php for($i = 1; $i < 6; $i++): ?>
                                                        <?php if($review->ReviewUser->review_rating >= $i): ?>
                                                            <i class="bi-star-fill" style="color: #FFDE59;"></i>
                                                        <?php elseif(($i - $review->ReviewUser->review_rating) >= 1): ?>
                                                            <i class="bi-star" style="color: #FFDE59;"></i>
                                                        <?php elseif(fmod($review->ReviewUser->review_rating, 1) != 0): ?>
                                                            <i class="bi-star-half" style="color: #FFDE59;"></i>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                </div>
                                                <p class="m-0"><?php echo e($review->ReviewUser->review_content); ?></p>
                                                <p class="m-0 text-end">
                                                    <a href="<?php echo e(route('caretaker.detail-order', $review->job_id)); ?>" class="text-decoration-none" style="color: #FFDE59">Lihat Detail Order</a>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/caretaker/ulasan-saya.blade.php ENDPATH**/ ?>