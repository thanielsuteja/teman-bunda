<div class="navigation-bar">
    <ul class="to-active">
        <li class="<?php echo e(request()->is('user/home-page*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('user.home')); ?>">
                <span class="nav-icon"><i class="bi bi-house-door"></i></span>
                <span class="nav-title">Beranda</span>
            </a>
        </li>
        <li class="<?php echo e(request()->is('user/cari-caregiver*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('cari-caregiver')); ?>">
                <span class="nav-icon"><i class="bi bi-people-fill"></i></span>
                <span class="nav-title">Cari Caregiver</span>
            </a>
        </li>
        <li class="<?php echo e(request()->is('user/order*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('order')); ?>">
                <span class="nav-icon"><i class="bi bi-table"></i></span>
                <span class="nav-title">Order Saya</span>
            </a>
        </li>
        <li class="<?php echo e(request()->is('user/transaksi*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('transaksi')); ?>">
                <span class="nav-icon"><i class="bi bi-file-text"></i></span>
                <span class="nav-title">Riwayat Transaksi</span>
            </a>
        </li>
    </ul>
</div>

<link rel="stylesheet" href="<?php echo e(asset('css/style1.css')); ?>">
<?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/layout/sidebar/sidebar-user.blade.php ENDPATH**/ ?>