

<?php $__env->startSection('content'); ?>

<div class="container my-5 p-2 ">
    <section class="row py-5">
        <h1 class="container rounded bg-danger p-2">Access Denied!</h1>
        <div class="container rounded bg-light p-2">
         You have been logged out as you do not have the necessary clearance to access to this page.
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/accessdenied.blade.php ENDPATH**/ ?>