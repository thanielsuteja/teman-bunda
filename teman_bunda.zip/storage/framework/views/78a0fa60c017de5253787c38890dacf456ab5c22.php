
<?php $__env->startSection('title','Status order | Teman Bunda'); ?>
<?php echo $__env->make('layout.navbar.navbar-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.sidebar.sidebar-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .line {
        border-left: 5px solid white;
        height: 3px;
    }
</style>
<div class="container main col-xxl-12 px-5">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card mb-5 shadow" style="border-radius: 20px; overflow: hidden;">
                <div class="card-header row bg-temanbunda p-0 align-items-center" style="height: 107px;">
                    <p class="m-0 ms-5" style="font-size: 36px;">Status Order Saya</p>
                </div>
                <div class="card-body"></div>
                <?php $__currentLoopData = $job_offer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card border-2 mx-4 my-2 zoom" style="background-color: #f3f3f3; border-radius: 10px; overflow: hidden;">
                    <div class="card-header d-flex align-items-center p-0" style="background-color: #ffeea8;">
                        <div class="col-sm-10 border-end border-5 border-white">
                            <p class="my-2 ps-4" style="font-size: 26px;"><?php echo e($job->judul_pekerjaan); ?></p>
                        </div>
                        <div class="col-sm-2 text-center p-0 d-flex align-items-center">
                            <?php if($job->job_status == "menunggu"): ?>
                            <p class="text-808080" style="font-size: 17px; margin: 0;"><?php echo e($job->job_status); ?></p>
                            <?php elseif($job->job_status == "ditolak"): ?>
                            <p class="text-danger" style="font-size: 17px; margin: 0;"><?php echo e($job->job_status); ?></p>
                            <?php elseif($job->job_status == "ubah gaji"): ?>
                            <p class="text-dark" style="font-size: 17px; margin: 0;"><?php echo e($job->job_status); ?></p>
                            <?php elseif($job->job_status == "berlangsung"): ?>
                            <p class="text-primary" style="font-size: 17px; margin: 0;"><?php echo e($job->job_status); ?></p>
                            <?php elseif($job->job_status == "selesai"): ?>
                            <p class="text-success" style="font-size: 17px; margin: 0;"><?php echo e($job->job_status); ?></p>
                            <?php endif; ?>
                            </p>
                        </div>
                    </div>
                    <div class="card-body"></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/user/status-order.blade.php ENDPATH**/ ?>