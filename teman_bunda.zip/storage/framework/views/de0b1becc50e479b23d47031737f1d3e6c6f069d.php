<?php $__env->startSection('content'); ?>

<!-- <div class="header">
    <div class="header-menu">
        <div class="title">Coding <span>Snow</span></div>
        <div class="sidebar-btn">

        </div>
    </div>
</div> -->

<div class="row">
    <div class="col-md-4">
        <div class="card mx-5 my-5">
            <div class="card-title">
                <h2>TITLE</h2>
            </div>
            <div class="card-body mt-5">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum consequatur fugiat aliquid commodi aperiam aspernatur illo consectetur vel ullam accusamus, nobis corrupti dolorem saepe animi assumenda inventore quidem praesentium quos.</p>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/dashboard.blade.php ENDPATH**/ ?>