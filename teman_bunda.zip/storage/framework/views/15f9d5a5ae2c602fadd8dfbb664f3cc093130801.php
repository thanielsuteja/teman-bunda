

<?php $__env->startSection('content'); ?>
    <div class="container rounded border border-dark bg-dark p-5" style="margin-left:20%; margin-top:5%; height:50%">

        <div class="container rounded p-3 mb-4 bg-primary text-white">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Profession Data
            </h2>
        </div>

        <div class="container rounded bg-white p-3">
            

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session('success')); ?></strong> 
                            <button type="button" class="btn-close"  data-bs-dismiss="alert" aria-label="Close">
                            </button>
                        </div>
                    <?php endif; ?>

                    <div class="card-header">Professions</div>

                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col"></th>
                                <th scope="col"></th>
                                <th scope="col"></th>
                                <th scope="col"></th>
                                <th scope="col"></th>
                                <th scope="col"></th>
                                <th scope="col"><a href="<?php echo e(url('/admin/professions/new')); ?>" class="btn btn-info">Add New Profession</a></th>
                            </tr>
                            <tr>
                                <th scope="col">num</th>
                                <th scope="col">profession_id</th>
                                <th scope="col">profession_name</th>
                                <th scope="col">description</th>
                                <th scope="col">created_at</th>
                                <th scope="col">updated_at</th>
                                <th scope="col">action</th>
                            </tr>
                            
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $professions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <th scope="row"><?php echo e($professions->firstItem()+$loop->index); ?></th>
                            <td><?php echo e($profession->profession_id); ?></td>
                            <td><?php echo e($profession->profession_name); ?></td>
                            <td><?php echo e($profession->profession_desc); ?></td>
                            <td>
                                <?php if($profession->created_at==NULL): ?>
                                <span class="text-danger">No Date Set</span>
                                <?php else: ?>
                                <?php echo e($profession->created_at); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($profession->updated_at==NULL): ?>
                                <span class="text-danger">No Date Set</span>
                                <?php else: ?>
                                <?php echo e($profession->updated_at); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(url('admin/professions/edit/'.$profession->profession_id)); ?>" class="btn btn-info">Edit</a>
                                <a href="<?php echo e(url('admin/professions/delete/'.$profession->profession_id)); ?>" class="btn btn-danger">Delete</a>
                            </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                    <?php echo e($professions->links()); ?>

                    
                    
                
            
        </div>
        
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.navbar.adminSB', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/admin/profession/professions.blade.php ENDPATH**/ ?>