

<?php $__env->startSection('content'); ?>
<div class="container rounded  bg-dark p-5" style="margin-left:20%; margin-top:5%; margin-bottom:5%; height:50%">

    <div class="container rounded p-3 mb-4 bg-primary text-white">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Job Offer Data
        </h2>
    </div>

    <div class="container rounded bg-white p-3">

        <div class="card-header">Displaying data of job_offer: <?php echo e($job_offers->job_id); ?></div>

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Field</th>
                    <th scope="col">Value</th>

                </tr>
            </thead>

            <tbody>

                <tr>
                    <td>job_id</td>
                    <td><?php echo e($job_offers->job_id); ?></td>
                </tr>
                <tr>
                    <td>job_status</td>
                    <td><?php echo e($job_offers->job_status); ?></td>
                </tr>
                <tr>
                    <td>user_id</td>
                    <td><?php echo e($job_offers->user_id); ?></td>
                </tr>
                <tr>
                    <td>caretaker_id</td>
                    <td><?php echo e($job_offers->caretaker_id); ?></td>
                </tr>
                <tr>
                    <td>judul_pekerjaan</td>
                    <td><?php echo e($job_offers->judul_pekerjaan); ?></td>
                </tr>
                <tr>
                    <td>deskripsi_pekerjaan</td>
                    <td><?php echo e($job_offers->deskripsi_pekerjaan); ?></td>
                </tr>
                <tr>
                    <td>tanggal_masuk</td>
                    <td><?php echo e(date('d/m/Y', strtotime($job_offers->tanggal_masuk))); ?></td>
                </tr>
                <tr>
                    <td>tanggal_berakhir</td>
                    <td><?php echo e(date('d/m/Y', strtotime($job_offers->tanggal_berakhir))); ?></td>
                </tr>
                <tr>
                    <td>jam_masuk</td>
                    <td><?php echo e($job_offers->jam_masuk); ?></td>
                </tr>
                <tr>
                    <td>jam_berakhir</td>
                    <td><?php echo e($job_offers->jam_berakhir); ?></td>
                </tr>
                <tr>
                    <td>hari_kerja</td>
                    <td>
                        <?php if( $job_offers->wd_1): ?>
                        Senin
                        <?php endif; ?>
                        
                        <?php if( $job_offers->wd_2): ?>
                        Selasa
                        <?php endif; ?>

                        <?php if( $job_offers->wd_3): ?>
                        Rabu
                        <?php endif; ?>

                        <?php if( $job_offers->wd_4): ?>
                        Kamis
                        <?php endif; ?>

                        <?php if( $job_offers->wd_5): ?>
                        Jumat
                        <?php endif; ?>

                        <?php if( $job_offers->wd_6): ?>
                        Sabtu
                        <?php endif; ?>

                        <?php if( $job_offers->wd_7): ?>
                        Minggu
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>estimasi_biaya</td>
                    <td>Rp<?php echo e(number_format($job_offers->estimasi_biaya, 2, ",", ".")); ?></td>
                </tr>
                <tr>
                    <td>created_at</td>
                    <td><?php echo e($job_offers->created_at); ?></td>
                </tr>
                <tr>
                    <td>updated_at</td>
                    <td><?php echo e($job_offers->updated_at); ?></td>
                </tr>


            </tbody>
        </table>

        <a href="<?php echo e(url('admin/job_offers')); ?>" class="btn btn-primary float-right">Back</a>
    </div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.navbar.adminSB', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/admin/job_offer/job_offer_details.blade.php ENDPATH**/ ?>