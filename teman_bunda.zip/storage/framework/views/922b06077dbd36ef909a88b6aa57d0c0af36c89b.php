
<?php $__env->startSection('title', 'Riwayat'); ?>
<?php echo $__env->make('layout.navbar.navbar-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.sidebar.sidebar-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<div class="container col-xxl-12 px-5">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card mb-2 shadow" style="border-radius: 20px; overflow: hidden; margin-top: 90px;">
                <div class="card-header row bg-temanbunda p-0 align-items-center" style="height: 107px;">
                    <p class="m-0 ms-5" style="font-size: 36px;">Riwayat Transaksi</p>
                </div>
                <div class="card-body" style="min-height: 532px;">
                    <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/user/info-transaksi/<?php echo e($transaction->transaction_id); ?>" class="text-decoration-none" style="color: black;">
                        <div class="card border-2 mx-4 my-4 zoom" style="background-color: #f3f3f3; border-radius: 10px; overflow: hidden;">
                            <div class="card-header d-flex align-items-center p-0" style="background-color: #ffeea8;">
                                <div class="col-sm-10 border-end border-5 border-white">
                                    <p class="my-2 ps-4" style="font-size: 26px;"><?php echo e($transaction->JobOffer->judul_pekerjaan); ?></p>
                                </div>
                                <div class="col-sm-2 text-center p-0">
                                    <?php if($transaction->transaction_status == "menunggu"): ?>
                                    <p class="text-808080 fw-bold" style="font-size: 17px; margin: 0;"><?php echo e(ucfirst($transaction->transaction_status)); ?></p>
                                    <?php elseif($transaction->transaction_status == "terbayar"): ?>
                                    <p class="fw-bold" style="color: #0063BE; font-size: 17px; margin: 0;"><?php echo e(ucfirst($transaction->transaction_status)); ?></p>
                                    <?php elseif($transaction->transaction_status == "terverifikasi"): ?>
                                    <p class="fw-bold" style=" color: #0EAD00; font-size: 17px; margin: 0;"><?php echo e(ucfirst($transaction->transaction_status)); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3 px-2 text-center">
                                        <?php if($transaction->JobOffer->Caretaker->User->profile_img_path != null): ?>
                                        <img src="<?php echo e(asset('storage/foto_profil/'.$transaction->JobOffer->Caretaker->User->profile_img_path)); ?>" class="profile-pic border border-5">
                                        <?php else: ?>
                                        <img src="<?php echo e(asset('img/no-profile.png')); ?>" class="profile-pic border border-5">
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-9">
                                        <table>
                                            <tr>
                                                <td class="text-808080">Nomor transaksi</td>
                                                <td><?php echo e($transaction->transaction_id); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-808080">Nama Caregiver</td>
                                                <td><?php echo e($transaction->JobOffer->Caretaker->User->nama_depan); ?> <?php echo e($transaction->JobOffer->Caretaker->User->nama_belakang); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-808080">Tanggal bekerja</td>
                                                <td><?php echo e($transaction->JobOffer->tanggal_masuk); ?> - <?php echo e($transaction->JobOffer->tanggal_berakhir); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-808080">Jumlah yang dibayar</td>
                                                <td><?php echo e(number_format($transaction->transaction_ammount, 0, ",", ".")); ?>,00</td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teman_bunda\resources\views/user/riwayat-transaksi.blade.php ENDPATH**/ ?>